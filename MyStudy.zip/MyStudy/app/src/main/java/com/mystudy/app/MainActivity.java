
package com.mystudy.app;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private PrefsManager prefsManager;

    private LinearLayout rootLayout;
    private LinearLayout targetPage;
    private LinearLayout coursesPage;
    private LinearLayout activityPage;

    private ScrollView homePage;
    private ScrollView settingsPage;

    private EditText etName;
    private EditText etTarget;
    private EditText etSubject;
    private EditText etDuration;
    private EditText etDescription;
    private EditText etNewCourse;

    private Switch switchDarkMode;
    private Switch switchNotifications;

    private TextView tvWelcome;
    private TextView tvTarget;
    private TextView tvProgress;
    private TextView tvStatus;
    private TextView tvSummary;
    private TextView tvActivityHistory;

    private LinearLayout courseListContainer;

    private Button btnSave;
    private Button btnSaveTarget;
    private Button btnSaveActivity;
    private Button btnAddCourse;

    private boolean isLoading = false;

    private static final String SEPARATOR = "\u001F";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefsManager = new PrefsManager(this);

        // MENGHUBUNGKAN HALAMAN
        rootLayout = findViewById(R.id.rootLayout);
        homePage = findViewById(R.id.homePage);
        settingsPage = findViewById(R.id.settingsPage);
        targetPage = findViewById(R.id.targetPage);
        coursesPage = findViewById(R.id.coursesPage);
        activityPage = findViewById(R.id.activityPage);

        // MENGHUBUNGKAN INPUT
        etName = findViewById(R.id.etName);
        etTarget = findViewById(R.id.etTarget);
        etSubject = findViewById(R.id.etSubject);
        etDuration = findViewById(R.id.etDuration);
        etDescription = findViewById(R.id.etDescription);

        // MENGHUBUNGKAN SWITCH
        switchDarkMode = findViewById(R.id.switchDarkMode);
        switchNotifications = findViewById(R.id.switchNotifications);

        // MENGHUBUNGKAN TEXT
        tvWelcome = findViewById(R.id.tvWelcome);
        tvTarget = findViewById(R.id.tvTarget);
        tvProgress = findViewById(R.id.tvProgress);
        tvStatus = findViewById(R.id.tvStatus);
        tvSummary = findViewById(R.id.tvSummary);
        tvActivityHistory = findViewById(R.id.tvActivityHistory);

        // MENGHUBUNGKAN TOMBOL
        btnSave = findViewById(R.id.btnSave);
        btnSaveTarget = findViewById(R.id.btnSaveTarget);
        btnSaveActivity = findViewById(R.id.btnSaveActivity);

        // MEMBUAT MENU MATA KULIAH
        createCourseMenu();

        // NAVIGASI BAWAH
        findViewById(R.id.navHome).setOnClickListener(v ->
                showPage("home"));

        findViewById(R.id.navActivity).setOnClickListener(v -> {
            updateActivityHistory();
            showPage("activity");
        });

        findViewById(R.id.navSettings).setOnClickListener(v ->
                showPage("settings"));

        // MENU BERANDA
        findViewById(R.id.btnSettings).setOnClickListener(v ->
                showPage("settings"));

        findViewById(R.id.btnTarget).setOnClickListener(v -> {
            etTarget.setText(
                    String.valueOf(prefsManager.getTarget()));
            showPage("target");
        });

        findViewById(R.id.btnCourses).setOnClickListener(v -> {
            updateCourseList();
            showPage("courses");
        });

        findViewById(R.id.btnActivity).setOnClickListener(v -> {
            updateActivityHistory();
            showPage("activity");
        });

        // SIMPAN PENGATURAN
        btnSave.setOnClickListener(v -> saveSettings());

        // DARK MODE
        switchDarkMode.setOnCheckedChangeListener(
                (buttonView, isChecked) -> {
                    if (!isLoading) {
                        prefsManager.saveDarkMode(isChecked);
                        applyTheme();
                    }
                });

        // NOTIFIKASI
        switchNotifications.setOnCheckedChangeListener(
                (buttonView, isChecked) -> {
                    if (!isLoading) {
                        prefsManager.saveNotifications(isChecked);
                    }
                });

        // SIMPAN TARGET
        btnSaveTarget.setOnClickListener(v -> saveTarget());

        // SIMPAN AKTIVITAS
        btnSaveActivity.setOnClickListener(v -> saveActivity());

        // MEMUAT DATA
        loadPreferences();
        updateCourseList();
        updateActivityHistory();

        showPage("home");
    }

    // =====================================
    // PENGATURAN PROFIL
    // =====================================

    private void saveSettings() {

        String name = etName.getText().toString().trim();

        if (name.isEmpty()) {
            etName.setError("Nama tidak boleh kosong");
            return;
        }

        prefsManager.saveName(name);
        prefsManager.saveDarkMode(switchDarkMode.isChecked());
        prefsManager.saveNotifications(
                switchNotifications.isChecked());

        updateWelcome(name);
        tvStatus.setText("Pengaturan berhasil disimpan!");

        Toast.makeText(this,
                "Pengaturan berhasil disimpan",
                Toast.LENGTH_SHORT).show();

        applyTheme();
    }

    private void loadPreferences() {

        isLoading = true;

        String name = prefsManager.getName();

        etName.setText(name);
        switchDarkMode.setChecked(prefsManager.getDarkMode());
        switchNotifications.setChecked(
                prefsManager.getNotifications());

        updateWelcome(name);
        updateTarget();
        applyTheme();

        isLoading = false;
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (prefsManager != null && etName != null) {
            loadPreferences();
            updateCourseList();
            updateActivityHistory();
        }
    }

    private void updateWelcome(String name) {

        if (name.isEmpty()) {
            tvWelcome.setText("Halo, Selamat Datang!");
        } else {
            tvWelcome.setText("Halo, " + name + "!");
        }
    }

    // =====================================
    // TARGET BELAJAR
    // =====================================

    private void saveTarget() {

        String value = etTarget.getText().toString().trim();

        if (value.isEmpty()) {
            etTarget.setError("Masukkan target belajar");
            return;
        }

        int target;

        try {
            target = Integer.parseInt(value);
        } catch (NumberFormatException e) {
            etTarget.setError("Masukkan angka yang benar");
            return;
        }

        if (target < 1 || target > 24) {
            etTarget.setError("Target harus 1 sampai 24 jam");
            return;
        }

        prefsManager.saveTarget(target);
        updateTarget();

        Toast.makeText(this,
                "Target belajar berhasil disimpan",
                Toast.LENGTH_SHORT).show();

        showPage("home");
    }

    private void updateTarget() {

        int target = prefsManager.getTarget();
        int totalMinutes = getTodayStudyMinutes();

        int targetMinutes = target * 60;
        int remaining = Math.max(0, targetMinutes - totalMinutes);

        int percentage = Math.min(
                100,
                (int) ((totalMinutes * 100.0) / targetMinutes)
        );

        tvTarget.setText(target + " Jam");

        tvProgress.setText(
                "Sudah belajar: " + totalMinutes + " menit\n"
                        + "Sisa target: " + remaining + " menit\n"
                        + "Pencapaian: " + percentage + "%"
        );

        tvSummary.setText(
                "Total belajar hari ini: "
                        + totalMinutes + " menit"
        );
    }

    private int getTodayStudyMinutes() {

        int total = 0;

        String today = new SimpleDateFormat(
                "yyyy-MM-dd",
                Locale.getDefault()
        ).format(new Date());

        for (String record : prefsManager.getActivities()) {

            String[] data = record.split(SEPARATOR, 4);

            if (data.length == 4 && data[3].equals(today)) {
                try {
                    total += Integer.parseInt(data[1]);
                } catch (NumberFormatException ignored) {
                }
            }
        }

        return total;
    }

    // =====================================
    // MATA KULIAH
    // =====================================

    private void createCourseMenu() {

        // Membuat ulang isi halaman agar tidak duplikat
        coursesPage.removeAllViews();

        TextView title = new TextView(this);
        title.setText("Mata Kuliah");
        title.setTextSize(26);
        title.setTextColor(Color.parseColor("#243B64"));
        title.setTypeface(null, android.graphics.Typeface.BOLD);

        TextView subtitle = new TextView(this);
        subtitle.setText("Kelola daftar mata kuliah kamu.");
        subtitle.setTextSize(14);
        subtitle.setPadding(0, dp(8), 0, dp(15));

        etNewCourse = new EditText(this);
        etNewCourse.setHint("Nama mata kuliah");
        etNewCourse.setSingleLine(true);

        btnAddCourse = new Button(this);
        btnAddCourse.setText("Tambah Mata Kuliah");
        btnAddCourse.setAllCaps(false);

        courseListContainer = new LinearLayout(this);
        courseListContainer.setOrientation(LinearLayout.VERTICAL);

        coursesPage.addView(title);
        coursesPage.addView(subtitle);
        coursesPage.addView(etNewCourse);
        coursesPage.addView(btnAddCourse);
        coursesPage.addView(courseListContainer);

        btnAddCourse.setOnClickListener(v -> addCourse());
    }

    private void addCourse() {

        String course = etNewCourse.getText().toString().trim();

        if (course.isEmpty()) {
            etNewCourse.setError("Masukkan nama mata kuliah");
            return;
        }

        List<String> courses = prefsManager.getCourses();

        if (courses.contains(course)) {
            Toast.makeText(this,
                    "Mata kuliah sudah ada",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        courses.add(course);
        prefsManager.saveCourses(courses);

        etNewCourse.setText("");

        updateCourseList();

        Toast.makeText(this,
                "Mata kuliah berhasil ditambahkan",
                Toast.LENGTH_SHORT).show();
    }

    private void updateCourseList() {

        if (courseListContainer == null) {
            return;
        }

        courseListContainer.removeAllViews();

        List<String> courses = prefsManager.getCourses();

        if (courses.isEmpty()) {

            TextView empty = new TextView(this);
            empty.setText("Belum ada mata kuliah.");
            empty.setTextSize(15);
            empty.setPadding(0, dp(20), 0, dp(10));

            courseListContainer.addView(empty);
            return;
        }

        for (String course : courses) {

            LinearLayout item = new LinearLayout(this);
            item.setOrientation(LinearLayout.HORIZONTAL);
            item.setGravity(Gravity.CENTER_VERTICAL);

            TextView name = new TextView(this);
            name.setText(course);
            name.setTextSize(15);
            name.setTextColor(Color.DKGRAY);
            name.setPadding(dp(8), dp(12), dp(8), dp(12));

            name.setLayoutParams(new LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1
            ));

            Button delete = new Button(this);
            delete.setText("Hapus");
            delete.setAllCaps(false);

            delete.setOnClickListener(v -> {

                List<String> updated = prefsManager.getCourses();
                updated.remove(course);

                prefsManager.saveCourses(updated);
                updateCourseList();

                Toast.makeText(this,
                        "Mata kuliah dihapus",
                        Toast.LENGTH_SHORT).show();
            });

            item.addView(name);
            item.addView(delete);

            courseListContainer.addView(item);
        }
    }

    // =====================================
    // AKTIVITAS BELAJAR
    // =====================================

    private void saveActivity() {

        String subject = etSubject.getText().toString().trim();
        String durationText = etDuration.getText().toString().trim();
        String description = etDescription.getText().toString().trim();

        if (subject.isEmpty()) {
            etSubject.setError("Masukkan nama mata kuliah");
            return;
        }

        if (durationText.isEmpty()) {
            etDuration.setError("Masukkan durasi belajar");
            return;
        }

        int duration;

        try {
            duration = Integer.parseInt(durationText);
        } catch (NumberFormatException e) {
            etDuration.setError("Masukkan angka yang benar");
            return;
        }

        if (duration < 1) {
            etDuration.setError("Durasi minimal 1 menit");
            return;
        }

        if (description.isEmpty()) {
            etDescription.setError("Masukkan materi belajar");
            return;
        }

        String date = new SimpleDateFormat(
                "yyyy-MM-dd",
                Locale.getDefault()
        ).format(new Date());

        String record = subject + SEPARATOR
                + duration + SEPARATOR
                + description + SEPARATOR
                + date;

        List<String> activities = prefsManager.getActivities();

        activities.add(0, record);

        prefsManager.saveActivities(activities);

        etSubject.setText("");
        etDuration.setText("");
        etDescription.setText("");

        updateActivityHistory();
        updateTarget();

        Toast.makeText(this,
                "Aktivitas berhasil disimpan",
                Toast.LENGTH_SHORT).show();
    }

    private void updateActivityHistory() {

        List<String> activities = prefsManager.getActivities();

        if (activities.isEmpty()) {
            tvActivityHistory.setText(
                    "Belum ada aktivitas belajar.");
            return;
        }

        StringBuilder result = new StringBuilder();

        for (String record : activities) {

            String[] data = record.split(SEPARATOR, 4);

            if (data.length == 4) {

                result.append("Mata Kuliah: ")
                        .append(data[0])
                        .append("\nDurasi: ")
                        .append(data[1])
                        .append(" menit")
                        .append("\nMateri: ")
                        .append(data[2])
                        .append("\nTanggal: ")
                        .append(data[3])
                        .append("\n\n");
            }
        }

        tvActivityHistory.setText(result.toString());
    }

    // =====================================
    // NAVIGASI
    // =====================================

    private void showPage(String page) {

        homePage.setVisibility(View.GONE);
        settingsPage.setVisibility(View.GONE);
        targetPage.setVisibility(View.GONE);
        coursesPage.setVisibility(View.GONE);
        activityPage.setVisibility(View.GONE);

        switch (page) {

            case "home":
                homePage.setVisibility(View.VISIBLE);
                updateTarget();
                break;

            case "settings":
                settingsPage.setVisibility(View.VISIBLE);
                break;

            case "target":
                targetPage.setVisibility(View.VISIBLE);
                break;

            case "courses":
                coursesPage.setVisibility(View.VISIBLE);
                updateCourseList();
                break;

            case "activity":
                activityPage.setVisibility(View.VISIBLE);
                updateActivityHistory();
                break;
        }
    }

    // =====================================
    // DARK MODE
    // =====================================

    private void applyTheme() {

        boolean dark = prefsManager.getDarkMode();

        int background = dark
                ? Color.parseColor("#172033")
                : Color.parseColor("#F3F6FC");

        rootLayout.setBackgroundColor(background);
        homePage.setBackgroundColor(background);
        settingsPage.setBackgroundColor(background);
        targetPage.setBackgroundColor(background);
        coursesPage.setBackgroundColor(background);
        activityPage.setBackgroundColor(background);

        tvWelcome.setTextColor(
                dark ? Color.WHITE : Color.parseColor("#243B64"));

        tvTarget.setTextColor(
                dark ? Color.WHITE : Color.parseColor("#315B9A"));

        tvProgress.setTextColor(
                dark ? Color.WHITE : Color.parseColor("#718096"));

        tvSummary.setTextColor(
                dark ? Color.WHITE : Color.parseColor("#718096"));

        tvActivityHistory.setTextColor(
                dark ? Color.WHITE : Color.DKGRAY);

        tvStatus.setTextColor(
                dark ? Color.WHITE : Color.parseColor("#26834A"));

        if (etNewCourse != null) {
            etNewCourse.setTextColor(dark ? Color.WHITE : Color.BLACK);
        }

        if (courseListContainer != null) {
            for (int i = 0; i < courseListContainer.getChildCount(); i++) {
                View child = courseListContainer.getChildAt(i);

                if (child instanceof LinearLayout) {
                    LinearLayout item = (LinearLayout) child;

                    for (int j = 0; j < item.getChildCount(); j++) {
                        View sub = item.getChildAt(j);

                        if (sub instanceof TextView
                                && !(sub instanceof Button)) {
                            ((TextView) sub).setTextColor(
                                    dark ? Color.WHITE : Color.DKGRAY);
                        }
                    }
                } else if (child instanceof TextView) {
                    ((TextView) child).setTextColor(
                            dark ? Color.WHITE : Color.DKGRAY);
                }
            }
        }
    }

    private int dp(int value) {
        return (int) (value * getResources()
                .getDisplayMetrics().density);
    }
}
