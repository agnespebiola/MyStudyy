
package com.mystudy.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

public class PrefsManager {

    private static final String PREF_NAME = "MyStudyPrefs";

    private static final String KEY_NAME = "user_name";
    private static final String KEY_DARK_MODE = "dark_mode";
    private static final String KEY_NOTIFICATIONS = "notifications";
    private static final String KEY_TARGET = "daily_target";
    private static final String KEY_COURSES = "courses";
    private static final String KEY_ACTIVITIES = "activities";

    private final SharedPreferences preferences;

    public PrefsManager(Context context) {
        preferences = context.getSharedPreferences(
                PREF_NAME,
                Context.MODE_PRIVATE
        );
    }

    public void saveName(String name) {
        preferences.edit().putString(KEY_NAME, name).apply();
    }

    public String getName() {
        return preferences.getString(KEY_NAME, "");
    }

    public void saveDarkMode(boolean enabled) {
        preferences.edit().putBoolean(KEY_DARK_MODE, enabled).apply();
    }

    public boolean getDarkMode() {
        return preferences.getBoolean(KEY_DARK_MODE, false);
    }

    public void saveNotifications(boolean enabled) {
        preferences.edit().putBoolean(KEY_NOTIFICATIONS, enabled).apply();
    }

    public boolean getNotifications() {
        return preferences.getBoolean(KEY_NOTIFICATIONS, true);
    }

    public void saveTarget(int target) {
        preferences.edit().putInt(KEY_TARGET, target).apply();
    }

    public int getTarget() {
        return preferences.getInt(KEY_TARGET, 3);
    }

    // MENYIMPAN DAFTAR MATA KULIAH
    public void saveCourses(List<String> courses) {
        JSONArray array = new JSONArray();

        for (String course : courses) {
            array.put(course);
        }

        preferences.edit()
                .putString(KEY_COURSES, array.toString())
                .apply();
    }

    // MEMBACA DAFTAR MATA KULIAH
    public List<String> getCourses() {
        List<String> courses = new ArrayList<>();

        String data = preferences.getString(KEY_COURSES, "[]");

        try {
            JSONArray array = new JSONArray(data);

            for (int i = 0; i < array.length(); i++) {
                courses.add(array.getString(i));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return courses;
    }

    // MENYIMPAN RIWAYAT AKTIVITAS
    public void saveActivities(List<String> activities) {
        JSONArray array = new JSONArray();

        for (String activity : activities) {
            array.put(activity);
        }

        preferences.edit()
                .putString(KEY_ACTIVITIES, array.toString())
                .apply();
    }

    // MEMBACA RIWAYAT AKTIVITAS
    public List<String> getActivities() {
        List<String> activities = new ArrayList<>();

        String data = preferences.getString(KEY_ACTIVITIES, "[]");

        try {
            JSONArray array = new JSONArray(data);

            for (int i = 0; i < array.length(); i++) {
                activities.add(array.getString(i));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return activities;
    }
}
